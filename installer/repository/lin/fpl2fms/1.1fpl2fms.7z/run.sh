#!/bin/sh

cd "$(dirname "$0")"

LD_LIBRARY_PATH=lib ./FPL2FMS